-- Run this on RDS Primary
CREATE DATABASE IF NOT EXISTS grand_andhika_hotel;
USE grand_andhika_hotel;

CREATE TABLE IF NOT EXISTS guests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama_tamu VARCHAR(100) NOT NULL,
    no_telp VARCHAR(20) NOT NULL,
    no_kamar VARCHAR(10) NOT NULL,
    lama_inap INT NOT NULL DEFAULT 1,
    komentar TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS admin_users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert default admin (password: admin123)
INSERT INTO admin_users (username, password) VALUES 
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi');

-- Insert sample data
INSERT INTO guests (nama_tamu, no_telp, no_kamar, lama_inap, komentar) VALUES
('Budi Santoso', '081234567890', '101', 3, 'Kamar bersih, pelayanan ramah'),
('Siti Aminah', '085678901234', '205', 2, 'Sarapan enak, lokasi strategis'),
('Ahmad Hidayat', '081122334455', '310', 4, 'Kolam renang bersih, staf helpful');