<?php
// Konfigurasi Database
define('DB_HOST_READ', 'rds-replica-endpoint');   // GANTI dengan endpoint RDS Read Replica
define('DB_HOST_WRITE', 'rds-primary-endpoint');  // GANTI dengan endpoint RDS Primary
define('DB_USER', 'admin');
define('DB_PASS', 'HotelAdmin2026!');
define('DB_NAME', 'grand_andhika_hotel');
?>