<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
require_once 'config.php';

// Fungsi untuk mendapatkan identitas server
function getServerIdentity() {
    $hostname = gethostname();
    if ($hostname && $hostname != 'localhost') {
        return "Server: " . $hostname;
    }
    $local_ip = $_SERVER['SERVER_ADDR'] ?? '127.0.0.1';
    return "Server IP: " . $local_ip;
}

$message = '';
// Proses Tambah / Edit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $conn_write = new mysqli(DB_HOST_WRITE, DB_USER, DB_PASS, DB_NAME);
    if (!$conn_write->connect_error) {
        if (isset($_POST['add'])) {
            $stmt = $conn_write->prepare("INSERT INTO guests (nama_tamu, no_telp, no_kamar, lama_inap, komentar) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("sssis", $_POST['nama_tamu'], $_POST['no_telp'], $_POST['no_kamar'], $_POST['lama_inap'], $_POST['komentar']);
            $stmt->execute();
            $message = 'Data tamu berhasil ditambahkan.';
        } elseif (isset($_POST['edit'])) {
            $stmt = $conn_write->prepare("UPDATE guests SET nama_tamu=?, no_telp=?, no_kamar=?, lama_inap=?, komentar=? WHERE id=?");
            $stmt->bind_param("sssisi", $_POST['nama_tamu'], $_POST['no_telp'], $_POST['no_kamar'], $_POST['lama_inap'], $_POST['komentar'], $_POST['id']);
            $stmt->execute();
            $message = 'Data berhasil diperbarui.';
        }
        $conn_write->close();
    }
}

// Proses Hapus
if (isset($_GET['delete'])) {
    $conn_write = new mysqli(DB_HOST_WRITE, DB_USER, DB_PASS, DB_NAME);
    $stmt = $conn_write->prepare("DELETE FROM guests WHERE id = ?");
    $stmt->bind_param("i", $_GET['delete']);
    $stmt->execute();
    $conn_write->close();
    header('Location: admin.php?msg=deleted');
    exit;
}

// Ambil semua data untuk ditampilkan
$conn_write = new mysqli(DB_HOST_WRITE, DB_USER, DB_PASS, DB_NAME);
$result = $conn_write->query("SELECT * FROM guests ORDER BY created_at DESC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin · Grand Andhika Hotel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; background: #f8fafc; }
        .navbar-admin { background: white; box-shadow: 0 4px 12px rgba(0,0,0,0.02); padding: 1rem 0; }
        .card-modern { border: none; border-radius: 24px; background: white; box-shadow: 0 10px 30px rgba(0,0,0,0.04); }
        .table-admin { border-radius: 20px; overflow: hidden; }
        .table-admin thead { background: #1e293b; color: white; }
        .btn-gradient { background: linear-gradient(145deg, #2563eb, #4f46e5); border: none; color: white; border-radius: 40px; padding: 8px 20px; }
        .btn-soft-primary { background: #e0e7ff; color: #4f46e5; border-radius: 40px; padding: 8px 18px; font-weight: 600; }
        .btn-soft-primary:hover { background: #c7d2fe; }
        .modal-content { border-radius: 28px; border: none; }
        .server-info {
            background: #f1f5f9;
            padding: 6px 16px;
            border-radius: 40px;
            font-size: 0.75rem;
            color: #475569;
            display: inline-block;
        }
    </style>
</head>
<body>

<!-- Navbar Admin -->
<nav class="navbar-admin">
    <div class="container d-flex align-items-center">
        <a class="navbar-brand d-flex align-items-center" href="index.php">
            <i class="bi bi-building fs-3 me-2" style="color: #2563eb;"></i>
            <span class="fw-bold">Grand Andhika</span> <span class="text-muted ms-2">Admin</span>
        </a>
        <div class="ms-auto d-flex align-items-center">
            <span class="me-3 text-secondary"><i class="bi bi-person-check"></i> <?= htmlspecialchars($_SESSION['username']) ?></span>
            <a href="logout.php" class="btn btn-outline-secondary rounded-pill"><i class="bi bi-box-arrow-right"></i></a>
        </div>
    </div>
</nav>

<div class="container py-4">
    <!-- Info Server -->
    <div class="d-flex justify-content-end mb-3">
        <div class="server-info">
            <i class="bi bi-hdd-stack me-1"></i> <?= getServerIdentity() ?>
        </div>
    </div>

    <?php if ($message): ?>
        <div class="alert alert-success alert-dismissible fade show rounded-4 border-0 shadow-sm" role="alert">
            <i class="bi bi-check-circle-fill me-2"></i><?= $message ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php elseif (isset($_GET['msg'])): ?>
        <div class="alert alert-info alert-dismissible fade show rounded-4 border-0 shadow-sm" role="alert">
            <i class="bi bi-info-circle-fill me-2"></i>Data berhasil dihapus.
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="card-modern p-4">
        <div class="d-flex flex-wrap align-items-center justify-content-between mb-4">
            <h3 class="fw-bold mb-0"><i class="bi bi-journal-bookmark-fill me-2 text-primary"></i>Manajemen Buku Tamu</h3>
            <button class="btn btn-gradient mt-2 mt-sm-0" data-bs-toggle="modal" data-bs-target="#addModal">
                <i class="bi bi-plus-lg me-1"></i> Tambah Tamu Baru
            </button>
        </div>

        <div class="table-responsive">
            <table class="table table-hover align-middle table-admin">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nama Tamu</th>
                        <th>Kontak</th>
                        <th>Kamar</th>
                        <th>Inap</th>
                        <th>Check-in</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td>#<?= $row['id'] ?></td>
                        <td><i class="bi bi-person-badge me-2"></i><?= htmlspecialchars($row['nama_tamu']) ?></td>
                        <td><?= htmlspecialchars($row['no_telp']) ?></td>
                        <td><span class="badge bg-light text-dark"><?= htmlspecialchars($row['no_kamar']) ?></span></td>
                        <td><?= $row['lama_inap'] ?> mlm</td>
                        <td><?= date('d/m/Y', strtotime($row['created_at'])) ?></td>
                        <td>
                            <button class="btn btn-sm btn-soft-primary me-1" data-bs-toggle="modal" data-bs-target="#editModal<?= $row['id'] ?>">
                                <i class="bi bi-pencil"></i>
                            </button>
                            <a href="?delete=<?= $row['id'] ?>" class="btn btn-sm btn-outline-danger rounded-3" onclick="return confirm('Hapus data tamu ini?')">
                                <i class="bi bi-trash3"></i>
                            </a>
                        </td>
                    </tr>

                    <!-- Modal Edit -->
                    <div class="modal fade" id="editModal<?= $row['id'] ?>" tabindex="-1">
                        <div class="modal-dialog modal-dialog-centered">
                            <div class="modal-content p-3">
                                <form method="POST">
                                    <input type="hidden" name="id" value="<?= $row['id'] ?>">
                                    <div class="modal-header border-0">
                                        <h5 class="modal-title fw-bold">Edit Data Tamu</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="mb-3">
                                            <label>Nama</label>
                                            <input type="text" name="nama_tamu" class="form-control" value="<?= htmlspecialchars($row['nama_tamu']) ?>" required>
                                        </div>
                                        <div class="mb-3">
                                            <label>No. Telepon</label>
                                            <input type="text" name="no_telp" class="form-control" value="<?= htmlspecialchars($row['no_telp']) ?>" required>
                                        </div>
                                        <div class="row">
                                            <div class="col-6 mb-3">
                                                <label>Kamar</label>
                                                <input type="text" name="no_kamar" class="form-control" value="<?= htmlspecialchars($row['no_kamar']) ?>">
                                            </div>
                                            <div class="col-6 mb-3">
                                                <label>Inap</label>
                                                <input type="number" name="lama_inap" class="form-control" value="<?= $row['lama_inap'] ?>">
                                            </div>
                                        </div>
                                        <div class="mb-3">
                                            <label>Komentar</label>
                                            <textarea name="komentar" class="form-control" rows="2"><?= htmlspecialchars($row['komentar']) ?></textarea>
                                        </div>
                                    </div>
                                    <div class="modal-footer border-0">
                                        <button type="submit" name="edit" class="btn btn-primary rounded-pill px-4">Simpan</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
        <p class="text-muted small mt-3"><i class="bi bi-database-fill-check"></i> Data ditulis ke database PRIMARY.</p>
    </div>
</div>

<!-- Modal Tambah -->
<div class="modal fade" id="addModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content p-3">
            <form method="POST">
                <div class="modal-header border-0">
                    <h5 class="modal-title fw-bold">Tambah Tamu Baru</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label>Nama Lengkap</label>
                        <input type="text" name="nama_tamu" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label>No. Telepon</label>
                        <input type="text" name="no_telp" class="form-control" required>
                    </div>
                    <div class="row">
                        <div class="col-6 mb-3">
                            <label>Nomor Kamar</label>
                            <input type="text" name="no_kamar" class="form-control">
                        </div>
                        <div class="col-6 mb-3">
                            <label>Lama Inap</label>
                            <input type="number" name="lama_inap" class="form-control" value="1">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label>Komentar</label>
                        <textarea name="komentar" class="form-control" rows="2"></textarea>
                    </div>
                </div>
                <div class="modal-footer border-0">
                    <button type="submit" name="add" class="btn btn-gradient rounded-pill px-5">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>