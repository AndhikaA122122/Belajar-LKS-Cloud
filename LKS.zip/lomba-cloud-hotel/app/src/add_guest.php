<?php
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $conn_write = new mysqli(DB_HOST_WRITE, DB_USER, DB_PASS, DB_NAME);
    
    if ($conn_write->connect_error) {
        die("Koneksi gagal: " . $conn_write->connect_error);
    }
    
    $nama_tamu = $_POST['nama_tamu'] ?? '';
    $no_telp = $_POST['no_telp'] ?? '';
    $no_kamar = $_POST['no_kamar'] ?? '';
    $lama_inap = $_POST['lama_inap'] ?? 1;
    $komentar = $_POST['komentar'] ?? '';
    
    $stmt = $conn_write->prepare("INSERT INTO guests (nama_tamu, no_telp, no_kamar, lama_inap, komentar) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssis", $nama_tamu, $no_telp, $no_kamar, $lama_inap, $komentar);
    
    if ($stmt->execute()) {
        header('Location: index.php?success=1');
    } else {
        echo "Error: " . $stmt->error;
    }
    
    $stmt->close();
    $conn_write->close();
} else {
    header('Location: index.php');
}
exit;
?>